// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("format diff"); }
int main(){
  announce();
  return lionss_run_workload("format-diff");
}
