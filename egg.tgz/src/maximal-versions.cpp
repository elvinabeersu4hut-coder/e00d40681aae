// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("maximal versions"); }
int main(){
  announce();
  return lionss_run_workload("maximal-versions");
}
