// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("pch build"); }
int main(){
  announce();
  return lionss_run_workload("pch-build");
}
