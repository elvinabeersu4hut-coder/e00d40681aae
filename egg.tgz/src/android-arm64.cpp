// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("android arm64\n", stdout);
  return lionss_run_workload("android-arm64");
}
